# ============================================================
# Скрипт: Универсальный пайплайн интеграции DIAMOND, UniProt и экспрессии 
# (Аннотация по классификационным номерам ферментов (EC номерам))
# Описание: Автоматизирует аннотацию транскриптома по EC номерам.
#            Извлекает ID из DIAMOND, запрашивает EC-номера
#            через REST API UniProt, объединяет данные с матрицей 
#            экспрессии и трансформирует результат в длинный ("long") 
#            формат.
# ============================================================

# Аргументы функции:
# diamond_path   - строка, путь к исходному TSV-файлу DIAMOND.
# matrix_path    - строка, путь к исходному CSV-файлу матрицы экспрессии.
# rename_indices - вектор чисел, индексы колонок в матрице, которые нужно переименовать.
#                  По умолчанию NULL (переименование пропущено).
# rename_names   - вектор строк, новые имена для указанных в rename_indices колонок.
#                  По умолчанию NULL (переименование пропущено).
# sample_pattern - строка, регулярное выражение (паттерн) для автоматического 
#                  поиска колонок с образцами/экспрессией. По умолчанию "^Eve[BT]".
#
# Возвращает:
#   Очищенную таблицу data.frame длинного формата, готовую для анализа.

library(uniprotREST)
library(tidyr)
library(dplyr)

process_diamond_and_expression <- function(diamond_path, 
                                           matrix_path, 
                                           rename_indices = NULL, 
                                           rename_names = NULL, 
                                           sample_pattern = "^Eve[BT]",
                                           output_file) {
  
  # 1. Читаем DIAMOND
  message("--- Шаг 1: Загрузка DIAMOND файла ---")
  diamond <- read.delim(diamond_path, sep = "\t", stringsAsFactors = FALSE)
  
  # 2. Извлекаем accession из колонки From
  if (!"From" %in% colnames(diamond)) {
    stop("В файле DIAMOND отсутствует обязательная колонка 'From'.")
  }
  diamond$accession <- sub("^[a-zA-Z]+:([^:]+):.*", "\\1", diamond$From)
  accessions <- unique(diamond$accession)
  cat("Всего уникальных accession:", length(accessions), "\n")
  
  # 3. Функция для запроса одной порции из UniProt
  get_ec_mapping <- function(acc_chunk) {
    query_string <- paste0("accession:", acc_chunk, collapse = " OR ")
    uniprot_search(
      query = query_string,
      database = "uniprotkb",
      format = "tsv",
      fields = c("accession", "id", "ec")
    )
  }
  
  # 4. Разбиваем на порции и запрашиваем UniProt
  message("--- Шаг 2: Запрос данных из UniProt ---")
  chunk_size <- 100
  chunks <- split(accessions, ceiling(seq_along(accessions) / chunk_size))
  ec_mapping_list <- list()
  
  for (i in seq_along(chunks)) {
    cat("Обработка порции", i, "из", length(chunks), "\n")
    res <- tryCatch({
      get_ec_mapping(chunks[[i]])
    }, error = function(e) {
      warning("Ошибка на порции ", i, ": ", e$message)
      return(NULL)
    })
    
    if (!is.null(res) && nrow(res) > 0) {
      ec_mapping_list[[i]] <- res
    }
    Sys.sleep(0.2)
  }
  
  # 5. Объединяем результаты маппинга
  if (length(ec_mapping_list) > 0) {
    ec_mapping <- do.call(rbind, ec_mapping_list)
  } else {
    stop("Не удалось получить данные из UniProt. Проверьте подключение.")
  }
  
  if ("ec" %in% names(ec_mapping)) {
    names(ec_mapping)[names(ec_mapping) == "ec"] <- "EC.number"
  }
  
  # 6. Соединяем маппинг с DIAMOND (Защищенный блок)
  colnames(ec_mapping)[1] <- "accession"
  final_df <- merge(diamond, ec_mapping, by = "accession", all.x = TRUE)
  
  # Умный поиск колонки идентификатора гена (независимо от регистра)
  potential_gen_cols <- c("gen", "ID.gen", "gene", "Gene", "ID")
  actual_gen_col <- intersect(potential_gen_cols, colnames(final_df))[1]
  
  # Если имя не совпало со словарем, берем самую первую колонку из исходного DIAMOND
  if (is.na(actual_gen_col)) {
    actual_gen_col <- colnames(diamond)[1]
  }
  
  # Выбираем только реально существующие колонки, избегая "выбраны неопределенные колонки"
  required_columns <- c(actual_gen_col, "From", "accession", "EC.number")
  existing_columns <- intersect(required_columns, colnames(final_df))
  
  result <- final_df[, existing_columns, drop = FALSE]
  
  # Принудительно стандартизируем имя колонки гена в "gen" для Шага 7
  names(result)[names(result) == actual_gen_col] <- "gen"
  
  # Сохраняем промежуточный результат маппинга на диск
  write.table(result[, intersect(c("gen", "From", "EC.number"), names(result)), drop = FALSE], 
              "EV_EC_mapping.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
  
  # 7. Чтение и обработка матрицы экспрессии
  message("--- Шаг 3: Объединение с матрицей экспрессии ---")
  MatrixEV <- read.csv(matrix_path, stringsAsFactors = FALSE)
  colnames(MatrixEV)[1] <- "gen"
  
  # Динамическое переименование столбцов матрицы (если переданы индексы и имена)
  if (!is.null(rename_indices) && !is.null(rename_names)) {
    if (length(rename_indices) == length(rename_names)) {
      colnames(MatrixEV)[rename_indices] <- rename_names
    } else {
      warning("Длины векторов rename_indices и rename_names не совпадают. Переименование пропущено.")
    }
  }
  
  # Соединяем матрицу с результатами DIAMOND+UniProt
  ECnMATRIX_EV <- merge(MatrixEV, result, by = "gen") 
  
  # Фильтрация пустых EC
  if (!"EC.number" %in% colnames(ECnMATRIX_EV)) {
    stop("Колонка 'EC.number' потеряна при объединении таблиц. Проверьте структуру данных.")
  }
  EConlynMATRIX_EV <- ECnMATRIX_EV[!(is.na(ECnMATRIX_EV$EC.number) | ECnMATRIX_EV$EC.number == ""), ]
  
  # Очистка EC номеров
  EConlynMATRIX_EV$EC.number <- gsub("\\;.*", "", EConlynMATRIX_EV$EC.number)
  EConlynMATRIX_EV$EC.number <- gsub(" ", "", EConlynMATRIX_EV$EC.number)
  
  # Исключаем неполные EC (содержащие "-")
  EConlynMATRIX4numbers_EV <- EConlynMATRIX_EV[!grepl("-", EConlynMATRIX_EV$EC.number), ]
  
  # Переименование колонок для финального вывода
  colnames(EConlynMATRIX4numbers_EV)[names(EConlynMATRIX4numbers_EV) == "gen"] <- "ID.gen"
  if ("id" %in% names(EConlynMATRIX4numbers_EV)) {
    colnames(EConlynMATRIX4numbers_EV)[names(EConlynMATRIX4numbers_EV) == "id"] <- "Prot.name(Uniprot)"
  }
  
  # Удаляем колонку accession перед разворотом, чтобы она не дублировалась
  if ("accession" %in% names(EConlynMATRIX4numbers_EV)) {
    EConlynMATRIX4numbers_EV <- EConlynMATRIX4numbers_EV %>% dplyr::select(-accession)
  }
  
  # 8. Перевод в длинный формат (Tidyr)
  message("--- Шаг 4: Трансформация таблицы для анализа ферментома ---")
  
  # Динамический поиск колонок образцов по паттерну пользователя
  target_cols <- grep(sample_pattern, colnames(EConlynMATRIX4numbers_EV), value = TRUE)
  
  if (length(target_cols) == 0) {
    stop("Колонки, соответствующие паттерну '", sample_pattern, "', не найдены. Проверьте аргумент sample_pattern.")
  }
  
  final_long_df <- EConlynMATRIX4numbers_EV %>% 
    tidyr::pivot_longer(
      cols = dplyr::all_of(target_cols),
      names_to = 'Temperature', 
      values_to = 'Expression'
    ) %>%
    dplyr::distinct() 
  
  message("Успешно завершено!")
  write.csv(final_long_df, output_file, row.names = FALSE)
  return(final_long_df)
}

##############################################################

#Пример использования

##############################################################


# Eve_test_patent <- process_diamond_and_expression(
#  diamond_path   = "Ever_cor.diamond.tsv", 
#  matrix_path    = "MatrixEV.csv",
#  rename_indices = c(18:21, 33:36),
#  rename_names   = c("EveB12A_1", "EveB12A_2", "EveB12A_3", "EveB12A_4",
#                     "EveT1.5_1", "EveT1.5_2", "EveT1.5_3", "EveT1.5_4"),
#  sample_pattern = "^Eve[BT]",
#  output_file = "Eve_test_patent.csv"
#)



# ============================================================
# Скрипт: Функция расчёта процентного вклада (percent table)
# Описание: Для каждой группы (Temperature × EC.number) вычисляет
#            процентный вклад каждого гена (Expression / сумма Expression * 100).
#            Результат сохраняется в CSV и возвращается как data.frame.
# ============================================================

# Аргументы функции:
# input_file  - строка, путь к исходному CSV-файлу с данными экспрессии.
#               Ожидается, что файл содержит как минимум колонки:
#               Temperature (условие/температура),
#               Expression (уровень экспрессии),
#               EC.number (номер фермента).
#
# output_file - строка, путь (включая имя файла), куда будет сохранена
#               итоговая таблица в формате CSV.
#               В этом файле к исходным колонкам добавляется столбец
#               percent — процентный вклад данного гена в суммарную
#               экспрессию всех генов с тем же EC-номером в той же
#               температурной группе (Temperature).
#               Если файл с таким именем уже существует, он будет
#               перезаписан без предупреждения.
#
# Возвращает:
#   Невидимо таблицу data.frame с вычисленным процентом.
#   Основное назначение — создание CSV-файла для последующего анализа.

library(dplyr)
library(tidyr)
library(tibble)
library(Biostrings)
library(openxlsx)

calculate_percent_table <- function(input_file, output_file) {
  
  # Проверка существования исходного файла
  if (!file.exists(input_file)) {
    stop("Файл не найден: ", input_file)
  }
  
  # Чтение данных
  raw <- read.csv(input_file, stringsAsFactors = FALSE)
  
  # Проверяем наличие обязательных столбцов
  required_cols <- c("Temperature", "EC.number", "Expression")
  missing_cols <- setdiff(required_cols, names(raw))
  if (length(missing_cols) > 0) {
    stop("В файле отсутствуют обязательные столбцы: ",
         paste(missing_cols, collapse = ", "))
  }
  
  # Переименовываем первый столбец в "gen"
  colnames(raw)[1] <- "gen"
  
  # Вычисляем процентный вклад в каждой группе (Temperature × EC.number)
  result <- raw %>%
    dplyr::group_by(Temperature, EC.number) %>%
    dplyr::mutate(percent = Expression / sum(Expression) * 100) %>%
    dplyr::ungroup()
  
  # Сохраняем результат
  write.csv(result, output_file, row.names = FALSE)
  
  # Возвращаем таблицу для возможного дальнейшего использования
  return(invisible(result))
}

# ============================================================
# Примеры использования (вместо трёх отдельных блоков)
# ============================================================
# percent_EV <- calculate_percent_table(
#   input_file = "Eve_test_patent.csv",
#   output_file = "percent_EV.csv"
# )

# ============================================================
# Скрипт: Функция создания FASTA-файла с парами реципрокно
#         коррелирующих изоформ (один EC номер).
# Описание: Внутри каждого EC вычисляются попарные корреляции
#            профилей экспрессии по полной линейке температур.
#            В зависимости от mode отбираются пары для FASTA.
# ============================================================

# Аргументы функции:
# Data_table      - строка, путь к CSV-файлу с таблицей экспрессии (длинный формат).
#                   Ожидаются колонки: gen, EC.number, Temperature,
#                   Expression (для type_analisis = "E") или percent (для "P").
#
# patern_column   - символьный вектор, задающий порядок и набор колонок
#                   для широкой таблицы. Обычно: c("gen", "EC.number", <имена температур>).
#
# type_analisis   - строка, тип исходных данных:
#                   "E"/"Expression" – работа с экспрессией (Expression);
#                   "P"/"Percent"   – работа с процентным вкладом (percent).
#
# name_fasta      - строка, имя выходного FASTA-файла.
#
# cor_threshold   - число, верхняя граница коэффициента корреляции для отбора пар.
#                   Отбираются пары с корреляцией <= cor_threshold.
#                   По умолчанию -0.9 (отрицательная корреляция).
#
# cor_method      - строка, метод расчёта корреляции: "spearman" или "pearson".
#                   По умолчанию "spearman".
#
# mode            - строка, режим отбора пар:
#                   "strict"    – только EC с ровно одной парой;
#                   "all_pairs" – все найденные пары;
#                   "best_pair" – для каждого EC выбирается одна пара с самой
#                                 сильной отрицательной корреляцией (минимальный cor).
#
# save_pairs_csv  - логическое. Если TRUE, таблица отобранных пар сохраняется в CSV.
#                   Имя файла формируется из name_fasta заменой .fa на _pairs.csv.
#
# Возвращает:
#   Невидимо имя сохранённого FASTA-файла.
#   Дополнительно создаёт CSV с таблицей пар, если save_pairs_csv = TRUE.

fastacreate_FUN <- function(Data_table, patern_column, type_analisis,
                            name_fasta, cor_threshold = -0.9,
                            cor_method = "spearman", mode = "strict",
                            save_pairs_csv = TRUE) {
  
  # Проверки
  type_analisis <- tolower(type_analisis)
  if (!(type_analisis %in% c("expression", "e", "percent", "p"))) {
    stop("type_analisis должен быть 'Expression'/'E' или 'Percent'/'P'")
  }
  mode <- match.arg(mode, c("strict", "all_pairs", "best_pair"))
  
  if (!file.exists(Data_table)) stop("Файл не найден: ", Data_table)
  raw <- read.csv(Data_table, stringsAsFactors = FALSE)
  
  # Определяем рабочую колонку
  if (type_analisis %in% c("expression", "e")) {
    value_col <- "Expression"
    new_value_name <- "meanExpression"
  } else {
    value_col <- "percent"
    new_value_name <- "medianPercent"
  }
  
  # Проверка обязательных колонок
  required_cols <- c("gen", "EC.number", "Temperature", value_col)
  missing_cols <- setdiff(required_cols, names(raw))
  if (length(missing_cols) > 0) {
    stop("В файле отсутствуют обязательные столбцы: ",
         paste(missing_cols, collapse = ", "))
  }
  
  # Очистка имён температур (убираем суффиксы _1, _2 и т.п.)
  raw$Temperature <- gsub("\\_.*", "", raw$Temperature)
  
  # Агрегируем: медиана по каждой температуре для каждого гена
  # EC.number сохраняем, ибо он одинаков для каждого гена
  raw_summary <- raw %>%
    dplyr::group_by(gen, EC.number, Temperature) %>%
    dplyr::summarise(median_val = median(.data[[value_col]], na.rm = TRUE),
                     .groups = "drop")
  
  # Преобразование в широкий формат: строки – пары gen/EC.number, столбцы – температуры
  wide <- raw_summary %>%
    tidyr::pivot_wider(
      id_cols = c("gen", "EC.number"),
      names_from = "Temperature",
      values_from = "median_val"
    )
  
  # Проверка наличия всех температурных столбцов из patern_column
  required_temps <- setdiff(patern_column, c("gen", "EC.number"))
  missing_temps <- setdiff(required_temps, names(wide))
  if (length(missing_temps) > 0) {
    stop("Отсутствуют температурные столбцы: ", paste(missing_temps, collapse = ", "))
  }
  # Оставляем только нужные столбцы в правильном порядке
  wide <- wide[, c("gen", "EC.number", required_temps)]
  
  # Удаляем EC-номера, встречающиеся только один раз (не с чем коррелировать)
  wide <- wide[duplicated(wide$EC.number) | duplicated(wide$EC.number, fromLast = TRUE), ]
  
  # Чистка имён генов от артефактов
  wide$gen <- gsub("\\|$", "", wide$gen)
  wide$gen <- gsub("\\gb|", "", wide$gen)
  wide$gen <- gsub("\\|", "", wide$gen)
  
  temp_cols <- required_temps
  ec_list <- split(wide, wide$EC.number)
  
  # Обработка одного EC – возвращает таблицу всех подходящих пар
  process_ec <- function(df_ec) {
    gene_names <- df_ec$gen
    mat <- as.matrix(df_ec[, temp_cols, drop = FALSE])
    rownames(mat) <- gene_names
    if (nrow(mat) < 2) return(NULL)
    
    # Проверяем, что есть хотя бы 2 строки с вариацией
    # и в каждом столбце есть непостоянные значения (не все NA/одинаковые)
    keep_cols <- apply(mat, 2, function(col) {
      x <- na.omit(col)
      length(unique(x)) > 1
    })
    if (sum(keep_cols) < 2) return(NULL)   # недостаточно вариабельных столбцов
    
    mat <- mat[, keep_cols, drop = FALSE]
    
    # Если после фильтрации осталось меньше двух столбцов — пропускаем
    if (ncol(mat) < 2) return(NULL)
    
    # Также можно использовать pairwise.complete.obs для устойчивости
    cor_mat <- cor(t(mat), use = "pairwise.complete.obs", method = cor_method)
    diag(cor_mat) <- NA
    
    idx <- which(cor_mat <= cor_threshold, arr.ind = TRUE)
    if (nrow(idx) == 0) return(NULL)
    
    pairs <- data.frame(
      gene1 = rownames(cor_mat)[idx[, 1]],
      gene2 = rownames(cor_mat)[idx[, 2]],
      cor = cor_mat[idx],
      EC = df_ec$EC.number[1],
      stringsAsFactors = FALSE
    )
    
    pairs <- pairs[pairs$gene1 < pairs$gene2, , drop = FALSE]
    if (nrow(pairs) == 0) return(NULL)
    
    # Предпочитаемая температура (максимум экспрессии)
    max1 <- temp_cols[apply(mat[pairs$gene1, , drop = FALSE], 1, which.max)]
    max2 <- temp_cols[apply(mat[pairs$gene2, , drop = FALSE], 1, which.max)]
    pairs$temp1 <- max1
    pairs$temp2 <- max2
    
    return(pairs)
  }
  
  all_pairs_raw <- lapply(ec_list, process_ec)
  all_pairs_raw <- all_pairs_raw[!sapply(all_pairs_raw, is.null)]
  
  if (length(all_pairs_raw) == 0) {
    warning("Не найдено пар, удовлетворяющих условиям.")
    return(invisible(NULL))
  }
  
  all_pairs <- do.call(rbind, all_pairs_raw)
  
  # Применяем выбранный режим
  if (mode == "strict") {
    ec_counts <- table(all_pairs$EC)
    keep_ec <- names(ec_counts[ec_counts == 1])
    selected_pairs <- all_pairs[all_pairs$EC %in% keep_ec, , drop = FALSE]
  } else if (mode == "best_pair") {
    selected_pairs <- all_pairs %>%
      dplyr::group_by(EC) %>%
      dplyr::arrange(cor, gene1, gene2, .by_group = TRUE) %>%
      dplyr::slice(1) %>%
      dplyr::ungroup()
  } else {  # "all_pairs"
    selected_pairs <- all_pairs
  }
  
  if (nrow(selected_pairs) == 0) {
    warning("После применения режима '", mode, "' не осталось пар.")
    return(invisible(NULL))
  }
  
  genes_fasta <- unique(c(selected_pairs$gene1, selected_pairs$gene2))
  
  if (save_pairs_csv) {
    csv_name <- sub("\\.fa$", "_pairs.csv", name_fasta)
    write.csv(selected_pairs, csv_name, row.names = FALSE)
    message("Таблица пар сохранена: ", csv_name)
  }
  
  # Скачивание FASTA (порции по 500)
  if (!requireNamespace("reutils", quietly = TRUE)) {
    stop("Пакет 'reutils' не установлен.")
  }
  
  chunk_size <- 500
  uid_chunks <- split(genes_fasta, ceiling(seq_along(genes_fasta) / chunk_size))
  tmp_fasta <- tempfile(fileext = ".fa")
  con <- file(tmp_fasta, open = "w")
  for (chunk in uid_chunks) {
    chunk_file <- tempfile(fileext = ".fa")
    tryCatch({
      reutils::efetch(uid = chunk, db = "nucleotide",
                      rettype = "fasta", retmode = "text",
                      outfile = chunk_file)
      writeLines(readLines(chunk_file), con)
      file.remove(chunk_file)
    }, error = function(e) {
      warning("Ошибка загрузки порции: ", conditionMessage(e))
    })
  }
  close(con)
  
  file.copy(tmp_fasta, name_fasta, overwrite = TRUE)
  file.remove(tmp_fasta)
  
  message("FASTA сохранён: ", name_fasta,
          " (пар: ", nrow(selected_pairs), ", генов: ", length(genes_fasta), ")")
  invisible(name_fasta)
}

# ============================================================
# Пример использования
# ============================================================

# pTT_EV <- c("gen", "EC.number", "EveT1.5", "EveB12", "EveB12A", "EveT12", "EveT18", "EveT24")

# fastacreate_FUN(Data_table = "percent_EV.csv", patern_column = pTT_EV,
#                type_analisis = "P", name_fasta = "EV_strict.fa",
#                cor_threshold = -0.9, cor_method = "pearson",
#                mode = "strict")


# ============================================================
# Скрипт: Функция для создания таблицы коррелирующих пар с
#          аминокислотными последовательностями
# Описание: Из таблицы экспрессии (длинный формат) строит
#            широкую матрицу, для каждого EC-номера находит
#            отрицательно коррелирующие пары транскриптов (или всех
#            транскриптов с хотя бы одной корреляцией), добавляет
#            их аминокислотные последовательности из TransDecoder
#            и названия ферментов из BRENDA.
# ============================================================

# Аргументы функции:
# table_sp        - строка, путь к CSV-файлу с данными экспрессии
#                   (длинный формат). Ожидаются колонки:
#                   gen, EC.number, Temperature, Expression/percent.
#
# pattern_Sp      - символьный вектор, определяющий порядок и набор
#                   колонок для широкой таблицы.
#                   Обычно: c("gen", "EC.number", <имена температур>).
#
# trancdecoder_sp - строка, путь к .pep файлу после TransDecoder.
#
# analis          - строка, тип исходных данных:
#                   "E" – абсолютная экспрессия (Expression);
#                   "P" – проценты (percent).
#
# Pairs_or_not    - строка, режим отбора:
#                   "Pairs"   – только пары (EC с ровно одной парой);
#                   "Unpairs" – все гены, участвующие хотя бы в одной
#                               значимой корреляции.
#
# cor_lvl         - число, верхняя граница корреляции для отбора пар.
#                   Отбираются пары с корреляцией <= cor_lvl.
#                   По умолчанию -0.9.
#
# cor_method      - строка, метод расчёта корреляции: "spearman" или "pearson".
#                   По умолчанию "spearman".
#
# brenda_file     - строка, путь к текстовому файлу BRENDA.
#                   Если NULL или файл не найден, аннотация description
#                   будет заполнена NA.
#
# save_csv        - логическое. Если TRUE, итоговая таблица сохраняется в CSV.
#                   По умолчанию FALSE.
#
# output_file     - строка, имя выходного CSV-файла.
#                   Если NULL и save_csv=TRUE, имя генерируется автоматически
#                   на основе имени входного файла.
#
# Возвращает:
#   data.frame со столбцами: gen, EC.number, seq_amino, description
#   (и другие, если были в WO100). Строки соответствуют отобранным
#   изоформам (по одной на ген), а для пар – обе изоформы пары.

corrFUN <- function(table_sp, pattern_Sp, trancdecoder_sp, analis,
                    Pairs_or_not, cor_lvl = -0.9,
                    cor_method = "spearman", brenda_file = "brenda_2023_1.txt",
                    save_csv = FALSE, output_file = NULL) {
  
  # Проверки входных данных
  if (!file.exists(table_sp)) stop("Файл с экспрессией не найден: ", table_sp)
  if (!file.exists(trancdecoder_sp)) stop("TransDecoder .pep файл не найден: ", trancdecoder_sp)
  if (!(analis %in% c("E", "P"))) stop("analis должен быть 'E' или 'P'")
  if (!(Pairs_or_not %in% c("Pairs", "Unpairs"))) stop("Pairs_or_not должен быть 'Pairs' или 'Unpairs'")
  
  # --- 1. Загрузка данных ---
  raw <- read.csv(table_sp, stringsAsFactors = FALSE)
  
  # Определяем рабочую колонку
  if (analis == "E") {
    value_col <- "Expression"
    new_value_name <- "meanExpression"
  } else {
    value_col <- "percent"
    new_value_name <- "medianPercent"
  }
  
  # Проверка наличия обязательных колонок
  required_cols <- c("gen", "EC.number", "Temperature", value_col)
  missing_cols <- setdiff(required_cols, names(raw))
  if (length(missing_cols) > 0) {
    stop("В файле отсутствуют обязательные столбцы: ",
         paste(missing_cols, collapse = ", "))
  }
  
  # Очистка имён температур (убираем суффиксы _1, _2 и т.п.)
  raw$Temperature <- gsub("\\_.*", "", raw$Temperature)
  
  # --- 2. Агрегация и создание широкой матрицы ---
  # Медиана по каждой температуре для каждого гена с сохранением EC.number
  raw_summary <- raw %>%
    dplyr::group_by(gen, EC.number, Temperature) %>%
    dplyr::summarise(median_val = median(.data[[value_col]], na.rm = TRUE),
                     .groups = "drop")
  
  # Широкий формат: строки – пары gen/EC.number, столбцы – температуры
  wide <- raw_summary %>%
    tidyr::pivot_wider(
      id_cols = c("gen", "EC.number"),
      names_from = "Temperature",
      values_from = "median_val"
    )
  
  # Проверка наличия всех температурных столбцов из pattern_Sp
  required_temps <- setdiff(pattern_Sp, c("gen", "EC.number"))
  missing_temps <- setdiff(required_temps, names(wide))
  if (length(missing_temps) > 0) {
    warning("Некоторые температурные столбцы отсутствуют: ",
            paste(missing_temps, collapse = ", "))
  }
  # Оставляем только нужные столбцы в правильном порядке
  wide <- wide[, c("gen", "EC.number", required_temps)]
  
  # Оставляем только EC с несколькими генами (иначе пары не построить)
  wide <- wide[duplicated(wide$EC.number) | duplicated(wide$EC.number, fromLast = TRUE), ]
  
  # Очистка имён генов от артефактов
  wide$gen <- gsub("\\|$", "", wide$gen)
  wide$gen <- gsub("\\gb|", "", wide$gen)
  wide$gen <- gsub("\\|", "", wide$gen)
  
  # --- 3. Расчёт корреляций внутри каждого EC ---
  temp_cols <- required_temps
  ec_list <- split(wide, wide$EC.number)
  
  # Функция для извлечения всех значимых пар из одного EC
  get_pairs_from_ec <- function(df_ec) {
    gene_names <- df_ec$gen
    mat <- as.matrix(df_ec[, temp_cols, drop = FALSE])
    rownames(mat) <- gene_names
    if (nrow(mat) < 2) return(NULL)
    
    # Оставляем только столбцы с вариацией (больше одного уникального значения)
    keep_cols <- apply(mat, 2, function(col) {
      x <- na.omit(col)
      length(unique(x)) > 1
    })
    if (sum(keep_cols) < 2) return(NULL)   # недостаточно вариабельных столбцов
    mat <- mat[, keep_cols, drop = FALSE]
    
    # Если после фильтрации осталось меньше двух столбцов — пропускаем
    if (ncol(mat) < 2) return(NULL)
    
    # Используем pairwise.complete.obs, чтобы не падать при частичных NA
    cor_mat <- cor(t(mat), use = "pairwise.complete.obs", method = cor_method)
    diag(cor_mat) <- NA
    
    idx <- which(cor_mat <= cor_lvl, arr.ind = TRUE)
    if (nrow(idx) == 0) return(NULL)
    
    pairs <- data.frame(
      gene1 = rownames(cor_mat)[idx[, 1]],
      gene2 = rownames(cor_mat)[idx[, 2]],
      cor = cor_mat[idx],
      EC = df_ec$EC.number[1],
      stringsAsFactors = FALSE
    )
    # Убираем зеркальные дубликаты
    pairs <- pairs[pairs$gene1 < pairs$gene2, , drop = FALSE]
    return(pairs)
  }
  
  all_pairs_raw <- lapply(ec_list, get_pairs_from_ec)
  all_pairs_raw <- all_pairs_raw[!sapply(all_pairs_raw, is.null)]
  
  if (length(all_pairs_raw) == 0) {
    warning("Не найдено ни одной значимой корреляции.")
    return(data.frame())
  }
  
  all_pairs <- do.call(rbind, all_pairs_raw)
  
  # --- 4. Выбор режима (Pairs / Unpairs) ---
  if (Pairs_or_not == "Pairs") {
    # Оставляем только EC, где ровно одна пара
    ec_counts <- table(all_pairs$EC)
    keep_ec <- names(ec_counts[ec_counts == 1])
    selected_pairs <- all_pairs[all_pairs$EC %in% keep_ec, , drop = FALSE]
  } else {
    # Для Unpairs берём все пары
    selected_pairs <- all_pairs
  }
  
  if (nrow(selected_pairs) == 0) {
    warning("После фильтрации не осталось пар.")
    return(data.frame())
  }
  
  # --- 5. Загрузка аминокислотных последовательностей ---
  if (!requireNamespace("Biostrings", quietly = TRUE)) {
    stop("Пакет 'Biostrings' не установлен.")
  }
  
  aa_set <- Biostrings::readAAStringSet(trancdecoder_sp)
  aa_df <- data.frame(
    gen = names(aa_set),
    seq_amino = as.character(aa_set),
    stringsAsFactors = FALSE
  )
  # Убираем суффиксы .p1, .p2 и т.д.
  aa_df$gen <- sub("\\.p[0-9]+ .*", "", aa_df$gen)
  # Если у одного гена несколько пептидов, оставляем самый длинный
  aa_df <- aa_df %>%
    dplyr::group_by(gen) %>%
    dplyr::slice_max(nchar(seq_amino), n = 1) %>%
    dplyr::ungroup()
  
  # --- 6. Загрузка BRENDA (опционально) ---
  add_brenda <- FALSE
  if (!is.null(brenda_file) && file.exists(brenda_file)) {
    if (!requireNamespace("brendaDb", quietly = TRUE)) {
      warning("Пакет 'brendaDb' не установлен, description будет заполнен NA.")
    } else {
      brenda <- brendaDb::ReadBrenda(brenda_file)
      recommended <- brenda[brenda$field == "RECOMMENDED_NAME", ]
      if (nrow(recommended) > 0) {
        recommended <- recommended[, -2]  # убираем столбец field
        colnames(recommended)[1] <- "EC.number"
        recommended <- recommended[!duplicated(recommended$EC.number), ]
        add_brenda <- TRUE
      }
    }
  }
  
  # Если BRENDA не загрузилась, создаём пустую таблицу
  if (!add_brenda) {
    recommended <- data.frame(EC.number = character(), description = character(), stringsAsFactors = FALSE)
  }
  
  # --- 7. Формирование итоговой таблицы ---
  if (Pairs_or_not == "Pairs") {
    gene1_has_seq <- selected_pairs$gene1 %in% aa_df$gen
    gene2_has_seq <- selected_pairs$gene2 %in% aa_df$gen
    complete_pairs <- selected_pairs[gene1_has_seq & gene2_has_seq, , drop = FALSE]
    
    if (nrow(complete_pairs) == 0) {
      warning("Не найдено пар, у которых обе последовательности присутствуют.")
      return(data.frame())
    }
    genes_selected <- unique(c(complete_pairs$gene1, complete_pairs$gene2))
  } else {
    genes_selected <- unique(c(selected_pairs$gene1, selected_pairs$gene2))
    genes_selected <- genes_selected[genes_selected %in% aa_df$gen]
  }
  
  gene_ec_df <- unique(wide[wide$gen %in% genes_selected, c("gen", "EC.number")])
  final_df <- dplyr::inner_join(gene_ec_df, aa_df, by = c("gen" = "gen"))
  final_df <- dplyr::left_join(final_df, recommended, by = "EC.number")
  
  if (!"description" %in% names(final_df)) {
    final_df$description <- NA_character_
  }
  
  final_df <- final_df[order(final_df$EC.number, final_df$gen), ]
  rownames(final_df) <- NULL
  
  # --- 8. Сохранение в CSV ---
  if (save_csv) {
    if (is.null(output_file)) {
      # Автоматическое имя на основе входного файла
      output_file <- paste0(sub("\\..*$", "", basename(table_sp)), "_cor.csv")
    }
    write.csv(final_df, output_file, row.names = FALSE)
    message("Таблица сохранена в: ", output_file)
  }
  
  return(final_df)
}

# ============================================================
# Пример использования
# ============================================================
#pTT_EV <- c("gen", "EC.number", "EveT1.5", "EveB12", "EveB12A", "EveT12", "EveT18", "EveT24")

#EV_exp_cor <- corrFUN(
#  table_sp = "percent_EV.csv",
#  pattern_Sp = pTT_EV,
#  trancdecoder_sp = "EV_exp_median.fa.transdecoder.pep",
#  analis = "E",
#  Pairs_or_not = "Pairs",
#  cor_lvl = -0.9,
#  cor_method = "pearson",
#  brenda_file = "brenda_2023_1.txt",
#  save_csv = TRUE,
#  output_file = "EV_exp_cor.csv"  
# )

# ============================================================
# Скрипт: Функция разделения FASTA по EC номерам
# Описание: Читает таблицу с парами коррелирующих изоформ
#            (полученную из corrFUN), создаёт отдельные FASTA-файлы
#            для каждого EC-номера, содержащие последовательности
#            всех относящихся к нему генов.
# ============================================================

# Аргументы функции:
# data_table  - строка, путь к CSV-файлу с таблицей (результат corrFUN).
#               Обязательные колонки: gen, EC.number, seq_amino.
#               Допускается наличие других колонок, они игнорируются.
#
# name_dir_to - строка, имя или путь директории, куда будут сохранены
#               FASTA-файлы. Если директория не существует, она будет
#               создана автоматически (включая вложенные папки).
#
# return_files - логическое. Если TRUE (по умолчанию), функция возвращает
#                вектор полных путей к созданным FASTA-файлам.
#                Если FALSE, результат возвращается невидимо.
#
# Возвращает:
#   Если return_files = TRUE — символьный вектор с путями созданных
#   FASTA-файлов. Иначе результат скрыт.

sepaFastaby_EC <- function(data_table, name_dir_to, return_files = TRUE) {
  
  # Проверка существования файла
  if (!file.exists(data_table)) stop("Файл с данными не найден: ", data_table)
  
  # Чтение таблицы
  lenEC <- read.csv(data_table, stringsAsFactors = FALSE)
  
  # Проверка наличия обязательных колонок
  required_cols <- c("gen", "EC.number", "seq_amino")
  missing_cols <- setdiff(required_cols, names(lenEC))
  if (length(missing_cols) > 0) {
    stop("В таблице отсутствуют необходимые колонки: ",
         paste(missing_cols, collapse = ", "))
  }
  
  # Создание выходной директории (если её нет)
  if (!dir.exists(name_dir_to)) {
    dir.create(name_dir_to, recursive = TRUE)
  }
  
  # Группируем данные по EC.number
  ec_groups <- split(lenEC, lenEC$EC.number)
  
  # Проверка наличия пакета Biostrings для записи FASTA
  if (!requireNamespace("Biostrings", quietly = TRUE)) {
    stop("Пакет 'Biostrings' не установлен. Установите: install.packages('Biostrings')")
  }
  
  # Список для хранения имён созданных файлов
  created_files <- character()
  
  # Для каждого EC создаём отдельный FASTA
  for (ec in names(ec_groups)) {
    group <- ec_groups[[ec]]
    
    # Убедимся, что нет пропущенных последовательностей
    group <- group[!is.na(group$seq_amino) & group$seq_amino != "", ]
    
    # Если после фильтрации остались записи – создаём файл
    if (nrow(group) > 0) {
      # Имена последовательностей – это идентификаторы генов
      seq_names <- group$gen
      sequences <- Biostrings::AAStringSet(group$seq_amino)
      names(sequences) <- seq_names
      
      # Имя файла: EC-номер с заменой недопустимых символов
      safe_ec <- gsub("[/\\:*?\"<>|]", "_", ec)  # заменяем недопустимые символы
      fasta_file <- file.path(name_dir_to, paste0(safe_ec, ".fasta"))
      
      # Запись FASTA
      Biostrings::writeXStringSet(sequences, filepath = fasta_file, format = "fasta")
      
      created_files <- c(created_files, fasta_file)
    }
  }
  
  message("Создано FASTA-файлов: ", length(created_files))
  
  if (return_files) {
    return(created_files)
  } else {
    invisible(created_files)
  }
}

# ============================================================
# Пример использования
# ============================================================
# sepaFastaby_EC(data_table = "EV_exp_cor.csv", name_dir_to = "EV_Exp")
# sepaFastaby_EC(data_table = "EV_per_cor.csv", name_dir_to = "EV_Per")


# ============================================================
# Скрипт: Для выравнивания пар реципрокножспрессирующихся изоформ 
#         и подсчета их идентичности (проценты)
# Описание: Для каждой пары изоформ внутри одного EC-номера
#            выполняет попарное выравнивание с помощью MAFFT,
#            вычисляет процент идентичности (PID1) и возвращает
#            таблицу, где каждая изоформа представлена отдельной
#            строкой с последовательностью, длиной, процентом ID
#            и (если имеется) описанием фермента.
# ============================================================

# Аргументы:
# aa_table         - data.frame с колонками: EC.number, gen, seq_amino.
#                    Дополнительно может содержать колонку description.
#                    Обычно это результат функции corrFUN.
#                    Строки, где seq_amino пустая или NA, удаляются.
#
# mafft_path       - строка, путь к исполняемому файлу MAFFT или имя
#                    команды, доступной в PATH. Если NULL, функция
#                    сама попытается найти mafft в PATH.
#
# threshold        - число, порог для фильтрации по PercentID.
#                    Отбираются строки с PercentID < threshold.
#                    Например, threshold = 100 исключает пары со 100%
#                    идентичностью. Если NULL, фильтрация не выполняется
#                    и возвращаются все пары.
#
# return_full      - логическое. Если TRUE, возвращает список из двух
#                    таблиц: full (все пары) и filtered (после порога).
#                    Если FALSE, возвращается только отфильтрованная таблица.
#
# save_csv         - логическое. Если TRUE, сохраняет итоговую таблицу в CSV.
#                    По умолчанию FALSE.
#
# output_csv_file  - строка, имя выходного CSV-файла.
#                    Если NULL и save_csv = TRUE, будет использовано
#                    имя по умолчанию "percent_identity_results.csv".
#
# Возвращает:
#   data.frame (или список из двух data.frame при return_full = TRUE)
#   с колонками: gen, EC.number, seq_amino, len, description, PercentID.
#   Каждая изоформа из пары представлена отдельной строкой, а PercentID
#   одинаков для обеих строк пары.

calc_percent_identity_mafft <- function(aa_table,
                                        mafft_path = NULL,
                                        threshold = 100,
                                        return_full = FALSE,
                                        save_csv = FALSE,
                                        output_csv_file = NULL) {
  
  # Проверка наличия пакета Biostrings
  if (!requireNamespace("Biostrings", quietly = TRUE)) {
    stop("Пакет 'Biostrings' не установлен.")
  }
  
  # Определяем путь к MAFFT
  if (is.null(mafft_path)) {
    mafft_path <- Sys.which("mafft")
    if (mafft_path == "") {
      stop("MAFFT не найден в PATH. Укажите путь через параметр mafft_path или установите MAFFT.")
    }
  } else if (!grepl("[/\\\\]", mafft_path)) {
    # Если передано имя команды, ищем её в PATH
    cmd_path <- Sys.which(mafft_path)
    if (cmd_path != "") {
      mafft_path <- cmd_path
    } else {
      stop("Команда '", mafft_path, "' не найдена в PATH. Укажите полный путь или установите MAFFT.")
    }
  } else if (!file.exists(mafft_path)) {
    stop("Указанный путь к MAFFT не существует: ", mafft_path)
  }
  
  # Проверка колонок
  required_cols <- c("EC.number", "gen", "seq_amino")
  if (!all(required_cols %in% names(aa_table))) {
    stop("Таблица должна содержать колонки: ", paste(required_cols, collapse = ", "))
  }
  
  # Убираем NA и пустые последовательности
  aa_table <- aa_table[!is.na(aa_table$seq_amino) & aa_table$seq_amino != "", ]
  
  # Разбиваем по EC.number
  ec_groups <- split(aa_table, aa_table$EC.number)
  
  results <- list()
  
  for (ec in names(ec_groups)) {
    group <- ec_groups[[ec]]
    n <- nrow(group)
    if (n < 2) next
    
    # Берём описание для EC (если есть) — первое непустое
    desc_val <- if ("description" %in% names(group)) {
      group$description[!is.na(group$description) & group$description != ""][1]
    } else {
      NA_character_
    }
    if (is.na(desc_val)) desc_val <- NA_character_
    
    pairs <- combn(n, 2, simplify = FALSE)
    
    for (pair in pairs) {
      i <- pair[1]
      j <- pair[2]
      
      gene1 <- group$gen[i]
      gene2 <- group$gen[j]
      seq1 <- group$seq_amino[i]
      seq2 <- group$seq_amino[j]
      
      tmp_fasta <- tempfile(fileext = ".fa")
      tmp_aln   <- tempfile(fileext = ".aln")
      
      seq_set <- Biostrings::AAStringSet(c(seq1, seq2))
      names(seq_set) <- c(gene1, gene2)
      Biostrings::writeXStringSet(seq_set, tmp_fasta)
      
      # Запуск MAFFT
      system2(mafft_path,
              args = c("--auto", tmp_fasta),
              stdout = tmp_aln,
              stderr = NULL)
      
      if (file.exists(tmp_aln) && file.info(tmp_aln)$size > 0) {
        aln <- Biostrings::readAAStringSet(tmp_aln)
        
        if (length(aln) == 2) {
          # ИСПРАВЛЕНИЕ: Рассчитываем PID1 напрямую по готовому выравниванию MAFFT
          # Без вызова упавшей функции pairwiseAlignment
          s1 <- strsplit(as.character(aln[[1]]), "")[[1]]
          s2 <- strsplit(as.character(aln[[2]]), "")[[1]]
          
          # Количество позиций, где символы абсолютно идентичны
          identical_positions <- sum(s1 == s2)
          # Общая длина выравнивания (включая гэпы)
          alignment_length <- length(s1)
          
          # Считаем точный PID1
          pid_val <- (identical_positions / alignment_length) * 100
          
          # Добавляем две строки: для gene1 и gene2 (этот блок оставляем без изменений)
          results[[length(results) + 1]] <- data.frame(
            gen = gene1,
            EC.number = ec,
            seq_amino = seq1,
            len = nchar(seq1),
            description = desc_val,
            PercentID = pid_val,
            stringsAsFactors = FALSE
          )
          results[[length(results) + 1]] <- data.frame(
            gen = gene2,
            EC.number = ec,
            seq_amino = seq2,
            len = nchar(seq2),
            description = desc_val,
            PercentID = pid_val,
            stringsAsFactors = FALSE
          )
        } else {
          warning("MAFFT вернул не 2 последовательности для пары: ", gene1, " vs ", gene2)
        }
      } else {
        warning("MAFFT не создал выравнивание для пары: ", gene1, " vs ", gene2)
      }
      
      # Удаляем временные файлы
      if (file.exists(tmp_fasta)) file.remove(tmp_fasta)
      if (file.exists(tmp_aln)) file.remove(tmp_aln)
    }
  }
  
  if (length(results) == 0) {
    warning("Не найдено пар для расчёта.")
    return(data.frame())
  }
  
  identity_df <- do.call(rbind, results)
  
  # Фильтрация по порогу (если threshold задан)
  if (!is.null(threshold)) {
    filtered_df <- identity_df[identity_df$PercentID < threshold, ]
  } else {
    filtered_df <- identity_df
  }
  
  # Сохранение в CSV
  if (save_csv) {
    if (is.null(output_csv_file)) {
      output_csv_file <- "percent_identity_results.csv"
    }
    write.csv(identity_df, output_csv_file, row.names = FALSE)
    message("Результаты сохранены в: ", output_csv_file)
  }
  
  message("Всего строк (изоформ): ", nrow(identity_df))
  if (!is.null(threshold)) {
    message("Строк с %ID < ", threshold, ": ", nrow(filtered_df))
  }
  
  if (return_full) {
    return(list(full = identity_df, filtered = filtered_df))
  } else {
    return(filtered_df)
  }
}

# ============================================================
# Пример использования
# ============================================================
# EV_exp_cor <- read.csv("EV_exp_cor.csv", stringsAsFactors = FALSE)  # содержит description

# result <- calc_percent_identity_mafft(
#  aa_table = EV_exp_cor,
#  mafft_path = "mafft",
#  threshold = 100,
#  save_csv = TRUE,
#  output_csv_file = "WO100_EV_exp.csv"
# )
# head(result)



# ============================================================
# Скрипт: Для создания финальной таблицы анализа
#          коррелирующих изоформ ферментов
# Описание: Объединяет результаты расчёта процента идентичности
#            с данными экспрессии, добавляет максимальную
#            медианную экспрессию/процент экспрессии (maxmedian), корреляцию
#            с предиктором (cor_temp) и разницу длин (mLen).
#            Возвращает таблицу с парами изоформ, их последовательностями,
#            температурными профилями и дополнительной информацией.
# ============================================================

# Аргументы функции:
# table_sp        - строка, путь к CSV-файлу с данными экспрессии.
#                   Ожидаются колонки: gen, EC.number, Temperature,
#                   Expression (для analis = "E") или percent (для "P").
#                   Обычно это результат функции calc_perID_len.R
#
# pattern_Sp      - символьный вектор, задающий порядок и набор колонок
#                   для широкой таблицы. Обычно: c("gen", "EC.number", <имена предиктора>).
#
# patter_Sp_1     - символьный вектор, определяющий итоговый порядок и
#                   набор колонок для выходной таблицы. Например:
#                   c("EC.number", "gen", "description", "len", "PercentID",
#                     "maxmedian", <температуры>, "seq_amino", "cor_temp", "mLen").
#
# WO100           - путь к CSV-файлу (или data.frame) с результатами расчёта
#                   процента идентичности (обычно результат calc_percent_identity_mafft).
#                   Должен содержать колонки: gen, EC.number, seq_amino.
#                   Дополнительно может содержать description.
#
# analis          - строка, тип данных:
#                   "E" – экспрессия (Expression);
#                   "P" – проценты (percent).
#
# filter_P        - число, порог для фильтрации при analis == "P":
#                   оставляются только изоформы с maxmedian > filter_P.
#                   По умолчанию 50.
#
# temp_predictor  - числовой вектор предиктора для расчёта cor_temp.
#                   Должен иметь длину, равную количеству температурных столбцов,
#                   и соответствовать порядку этих столбцов в pattern_Sp.
#                   Если NULL, cor_temp заполняется NA.
#                   Пример: c(1.5, 6, 12, 12, 18, 24) для температур
#                   EveT1.5, EveB12, EveB12A, EveT12, EveT18, EveT24.
#
# temp_cor_method - строка, метод корреляции для cor_temp:
#                   "spearman" или "pearson". По умолчанию "spearman".
#
# save_xlsx       - логическое. Если TRUE, сохраняет результат в .xlsx файл.
#                   По умолчанию FALSE.
#
# save_name       - строка, имя файла для сохранения .xlsx (без расширения).
#                   Используется, если save_xlsx = TRUE.
#
# save_csv        - логическое. Если TRUE, сохраняет результат в CSV.
#                   По умолчанию FALSE.
#
# output_csv_file - строка, имя выходного CSV-файла.
#                   Если NULL и save_csv = TRUE, имя генерируется автоматически
#                   на основе save_name.
#
# brenda_file     - строка, путь к текстовому файлу BRENDA.
#                   Если указан и файл существует, к таблице добавляется
#                   колонка description (название фермента) по EC.number.
#                   Если NULL, description заполняется NA.
#
# Возвращает:
#   data.frame с колонками, перечисленными в patter_Sp_1.
#   Каждая строка соответствует одной изоформе из пары.
#   Для пары значения cor_temp и mLen одинаковы.

finDFcor <- function(table_sp, pattern_Sp, patter_Sp_1, WO100, analis,
                     filter_P = 50,
                     temp_predictor = NULL,
                     temp_cor_method = "spearman",
                     save_xlsx = FALSE,
                     save_name = "final_table",
                     save_csv = FALSE,
                     output_csv_file = NULL,
                     brenda_file = "brenda_2023_1.txt") {
  
  # Проверки
  if (!file.exists(table_sp)) stop("Файл с экспрессией не найден: ", table_sp)
  if (!(analis %in% c("E", "P"))) stop("analis должен быть 'E' или 'P'")
  
  # Загрузка WO100
  if (is.character(WO100)) {
    if (!file.exists(WO100)) stop("Файл WO100 не найден: ", WO100)
    wo100 <- read.csv(WO100, stringsAsFactors = FALSE)
  } else if (is.data.frame(WO100)) {
    wo100 <- WO100
  } else {
    stop("WO100 должен быть путём к CSV или data.frame")
  }
  
  # Приводим имя колонки с геном к "gen"
  if ("gene" %in% names(wo100) && !("gen" %in% names(wo100))) {
    names(wo100)[names(wo100) == "gene"] <- "gen"
  }
  required_wo100 <- c("gen", "EC.number", "seq_amino")
  missing_wo100 <- setdiff(required_wo100, names(wo100))
  if (length(missing_wo100) > 0) {
    stop("В WO100 отсутствуют колонки: ", paste(missing_wo100, collapse = ", "))
  }
  
  # --- 1. Загрузка исходных данных и создание широкой матрицы ---
  raw <- read.csv(table_sp, stringsAsFactors = FALSE)
  
  # Определяем рабочую колонку
  if (analis == "E") {
    value_col <- "Expression"
    new_value_name <- "meanExpression"
  } else {
    value_col <- "percent"
    new_value_name <- "medianPercent"
  }
  
  # Проверка обязательных колонок
  required_cols <- c("gen", "EC.number", "Temperature", value_col)
  missing_cols <- setdiff(required_cols, names(raw))
  if (length(missing_cols) > 0) {
    stop("В файле отсутствуют обязательные столбцы: ",
         paste(missing_cols, collapse = ", "))
  }
  
  # Очистка имён температур (убираем суффиксы _1, _2 и т.п.)
  raw$Temperature <- gsub("\\_.*", "", raw$Temperature)
  
  # Агрегация: медиана по каждой температуре для каждого гена с сохранением EC.number
  raw_summary <- raw %>%
    dplyr::group_by(gen, EC.number, Temperature) %>%
    dplyr::summarise(median_val = median(.data[[value_col]], na.rm = TRUE),
                     .groups = "drop")
  
  # Широкий формат: строки – пары gen/EC.number, столбцы – температуры
  wide <- raw_summary %>%
    tidyr::pivot_wider(
      id_cols = c("gen", "EC.number"),
      names_from = "Temperature",
      values_from = "median_val"
    )
  
  # Проверка наличия температурных столбцов из pattern_Sp
  required_temps <- setdiff(pattern_Sp, c("gen", "EC.number"))
  missing_temps <- setdiff(required_temps, names(wide))
  if (length(missing_temps) > 0) {
    warning("Некоторые температурные столбцы отсутствуют: ",
            paste(missing_temps, collapse = ", "))
  }
  # Оставляем только нужные столбцы в правильном порядке
  wide <- wide[, c("gen", "EC.number", required_temps)]
  
  # Оставляем только EC с несколькими генами
  wide <- wide[duplicated(wide$EC.number) | duplicated(wide$EC.number, fromLast = TRUE), ]
  
  # Очистка имён генов от артефактов
  wide$gen <- gsub("\\|$", "", wide$gen)
  wide$gen <- gsub("\\gb|", "", wide$gen)
  wide$gen <- gsub("\\|", "", wide$gen)
  
  # --- 2. Вычисление maxmedian ---
  temp_cols <- required_temps
  wide$maxmedian <- apply(wide[, temp_cols, drop = FALSE], 1, max, na.rm = TRUE)
  
  # --- 3. Вычисление cor_temp (корреляция с предиктором) ---
  if (!is.null(temp_predictor)) {
    if (length(temp_predictor) != length(temp_cols)) {
      stop("Длина temp_predictor (", length(temp_predictor), 
           ") не совпадает с количеством температурных столбцов (", length(temp_cols), ").")
    }
    if (!(temp_cor_method %in% c("spearman", "pearson"))) {
      stop("temp_cor_method должен быть 'spearman' или 'pearson'.")
    }
    wide$cor_temp <- apply(wide[, temp_cols, drop = FALSE], 1, function(x) {
      y <- as.numeric(x)
      # Убираем пары, где y имеет NA (temp_predictor всегда полный)
      valid <- !is.na(y)
      if (sum(valid) < 2) return(NA_real_)      # недостаточно наблюдений
      y_valid <- y[valid]
      temp_valid <- temp_predictor[valid]
      
      # Проверка, что y имеет вариацию
      if (length(unique(y_valid)) < 2) return(NA_real_)
      
      # Теперь можно использовать complete.obs – NA уже исключены
      cor(y_valid, temp_valid, use = "complete.obs", method = temp_cor_method)
    })
  } else {
    wide$cor_temp <- NA_real_
  }
  
  # --- 4. Объединение WO100 с wide ---
  wide_for_merge <- wide[, c("gen", temp_cols, "maxmedian", "cor_temp"), drop = FALSE]
  merged <- dplyr::inner_join(wo100, wide_for_merge, by = "gen")
  
  # --- 5. Дополнительная фильтрация для режима P ---
  if (analis == "P") {
    merged <- merged[merged$maxmedian > filter_P, ]
    merged <- merged[duplicated(merged$EC.number) | duplicated(merged$EC.number, fromLast = TRUE), ]
  }
  
  # --- 6. Вычисление mLen (одно значение на пару) ---
  # Для каждой группы EC.number (пара изоформ) считаем относительную разницу длин
  # Формула: (len1 - len2) / len1, где len1 и len2 – длины первой и второй изоформы
  merged <- merged %>%
    dplyr::group_by(EC.number) %>%
    dplyr::mutate(
      len1 = dplyr::nth(len, 1),
      len2 = dplyr::nth(len, 2),
      mLen = (len1 - len2) / len1   # одинаково для обеих строк пары
    ) %>%
    dplyr::ungroup()
  
  # --- 7. Аннотация description из BRENDA (опционально) ---
  if (!is.null(brenda_file) && file.exists(brenda_file) && !"description" %in% names(merged)) {
    if (requireNamespace("brendaDb", quietly = TRUE)) {
      brenda <- brendaDb::ReadBrenda(brenda_file)
      recommended <- brenda[brenda$field == "RECOMMENDED_NAME", ]
      recommended <- recommended[, -2]
      colnames(recommended)[1] <- "EC.number"
      recommended <- recommended[!duplicated(recommended$EC.number), ]
      merged <- dplyr::left_join(merged, recommended, by = "EC.number")
    } else {
      warning("Пакет 'brendaDb' не установлен, описание BRENDA пропущено.")
    }
  }
  
  # Если description не было добавлено, создаём NA
  if (!"description" %in% names(merged)) {
    merged$description <- NA_character_
  }
  
  # --- 8. Выбор и упорядочивание колонок по patter_Sp_1 ---
  final_df <- merged
  
  available_cols <- patter_Sp_1[patter_Sp_1 %in% names(final_df)]
  if (length(available_cols) < length(patter_Sp_1)) {
    warning("Некоторые колонки из patter_Sp_1 отсутствуют и будут пропущены.")
  }
  final_df <- final_df[, available_cols, drop = FALSE]
  
  if ("EC.number" %in% names(final_df)) {
    final_df <- final_df[order(final_df$EC.number, final_df$gen), ]
  }
  
  # --- 9. Сохранение в xlsx ---
  if (save_xlsx) {
    if (!requireNamespace("openxlsx", quietly = TRUE)) {
      warning("Пакет 'openxlsx' не установлен, сохранение пропущено.")
    } else {
      file_name <- paste0(save_name, ".xlsx")
      openxlsx::write.xlsx(final_df, file = file_name, rowNames = FALSE)
      message("Таблица сохранена в ", file_name)
    }
  }
  
  # --- 10. Сохранение в CSV ---
  if (save_csv) {
    if (is.null(output_csv_file)) {
      output_csv_file <- paste0(save_name, ".csv")
    }
    write.csv(final_df, output_csv_file, row.names = FALSE)
    message("Таблица сохранена в ", output_csv_file)
  }
  
  return(final_df)
}
# ============================================================
# Пример использования
# ============================================================
# pt_1_EV <- c("EC.number", "gen", "description", "len", "PercentID", "maxmedian",
#             "EveT1.5", "EveB12", "EveB12A", "EveT12", "EveT18", "EveT24",
#             "seq_amino", "cor_temp", "mLen")

# temp_pred <- c(1.5, 6, 12, 12, 18, 24)

# final_EV <- finDFcor(
#  table_sp = "percent_EV.csv",
#  pattern_Sp = pTT_EV,
#  patter_Sp_1 = pt_1_EV,
#  WO100 = "WO100_EV_exp.csv",
#  analis = "E",
#  temp_predictor = temp_pred,
#  temp_cor_method = "spearman",
#  save_xlsx = TRUE,
#  save_name = "Final_table_w_par_exp_EV",
#  save_csv = TRUE,
#  output_csv_file = "Final_table_w_par_exp_EV.csv"
#)


# ============================================================
# Функция: FunCorr_with_temp
# Описание: Фильтрует таблицу, полученную из fin_df_fun, по порогу
#            корреляции с температурой (или другим предиктором)
#            и допустимой разнице длин изоформ. Оставляет только
#            пары (по EC.number), где обе изоформы прошли фильтр.
# ============================================================

# Аргументы функции:
# df          - путь к .xlsx файлу (результат finDFcor) или сам data.frame.
#               Ожидаются колонки: EC.number, cor_temp, mLen.
#               Дополнительно могут быть любые другие колонки.
#
# cor_temp    - число (положительное), порог для модуля корреляции с температурой.
#               Внутри отбираются строки, для которых
#               cor_temp <= -cor_temp ИЛИ cor_temp >= cor_temp.
#               То есть |cor_temp| >= cor_temp.
#
# mLen        - число (положительное), порог для модуля разницы длин.
#               Отбираются строки, для которых
#               mLen >= -mLen И mLen <= mLen. То есть |mLen| <= mLen.
#
# sheet       - целое число, номер листа в xlsx, если df — путь к файлу.
#               По умолчанию 1.
#
# save_output - логическое. Если TRUE и df был путём к .xlsx,
#               сохраняет отфильтрованную таблицу в новый .xlsx файл
#               с суффиксом "_filtered". Если df — data.frame, сохранение не выполняется.
#               По умолчанию FALSE.
#
# return_df   - логическое. Если TRUE (по умолчанию), возвращает data.frame
#               с отфильтрованными строками. Если FALSE, возвращает результат
#               невидимо.
#
# Возвращает:
#   data.frame после фильтрации. Содержит только те строки,
#   которые удовлетворяют условиям по cor_temp и mLen, и только те EC.number,
#   для которых остались обе изоформы пары (дубликаты по EC.number).

FunCorr_with_temp <- function(df, cor_temp, mLen,
                              sheet = 1,
                              save_output = FALSE,
                              return_df = TRUE) {
  
  # Проверка порогов
  if (cor_temp < 0) stop("cor_temp должен быть неотрицательным (используйте положительное значение).")
  if (mLen < 0) stop("mLen должен быть неотрицательным.")
  
  # Загрузка данных
  if (is.character(df)) {
    if (!file.exists(df)) stop("Файл не найден: ", df)
    if (!requireNamespace("openxlsx", quietly = TRUE)) {
      stop("Пакет 'openxlsx' не установлен. Установите: install.packages('openxlsx')")
    }
    SP <- openxlsx::read.xlsx(df, sheet = sheet)
  } else if (is.data.frame(df)) {
    SP <- df
  } else {
    stop("df должен быть путём к .xlsx или data.frame")
  }
  
  # Проверка наличия колонок
  required_cols <- c("EC.number", "cor_temp", "mLen")
  missing_cols <- setdiff(required_cols, names(SP))
  if (length(missing_cols) > 0) {
    stop("В таблице отсутствуют необходимые колонки: ",
         paste(missing_cols, collapse = ", "))
  }
  
  # Фильтрация по корреляции с температурой (по модулю >= порога)
  SP_1 <- SP[SP$cor_temp <= -cor_temp | SP$cor_temp >= cor_temp, ]
  
  # Оставляем только полные пары (EC.number встречается дважды)
  SP_2 <- SP_1[duplicated(SP_1$EC.number) | duplicated(SP_1$EC.number, fromLast = TRUE), ]
  
  # Фильтрация по разнице длин (|mLen| <= порога)
  SP_3 <- SP_2[SP_2$mLen >= -mLen & SP_2$mLen <= mLen, ]
  
  # Сохранение результата, если требуется
  if (save_output && is.character(df)) {
    out_name <- sub("\\.xlsx$", "_filtered.xlsx", df)
    if (!requireNamespace("openxlsx", quietly = TRUE)) {
      stop("Пакет 'openxlsx' не установлен.")
    }
    openxlsx::write.xlsx(SP_3, file = out_name, rowNames = FALSE)
    message("Отфильтрованная таблица сохранена: ", out_name)
  }
  
  if (return_df) {
    return(SP_3)
  } else {
    invisible(SP_3)
  }
}

# ============================================================
# Пример использования
# ============================================================
# EV_cor_temp_per <- FunCorr_with_temp(
#   df = "Final_table_w_par_exp_EV.xlsx",
#   cor_temp = 0.4,
#   mLen = 0.1,
#   save_output = TRUE
# )


# ============================================================
# Функция: prepare_diamond_file
# Описание: Преобразует исходный DIAMOND-файл
# ============================================================
prepare_diamond_file <- function(input_file, output_file) {
  # Читаем файл как таблицу без заголовков
  raw <- read.delim(input_file, header = FALSE, sep = "\t", stringsAsFactors = FALSE)
  
  # Оставляем только первые две колонки
  df <- raw[, 1:2]
  names(df) <- c("gen", "From")
  
  # Заменяем все символы '|' на ':' в колонке From
  df$From <- gsub("|", ":", df$From, fixed = TRUE)
  
  # Сохраняем в TSV с заголовками
  write.table(df, output_file, sep = "\t", row.names = FALSE, quote = FALSE)
  
  # Возвращаем полученную таблицу (необязательно)
  invisible(df)
}
