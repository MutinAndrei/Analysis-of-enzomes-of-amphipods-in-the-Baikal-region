#!/bin/bash
# ============================================================
# Скрипт: Запуск TransDecoder для поиска ORF
# Описание:
#   Для каждого FASTA-файла, переданного как аргумент командной строки,
#   выполняются:
#     1) TransDecoder.LongOrfs  – поиск длинных ORF (--complete_orfs_only)
#     2) TransDecoder.Predict   – предсказание кодирующих областей (--single_best_only)
#
#   TransDecoder ищется в PATH. Если программы не найдены в PATH,
#   можно задать путь через переменную окружения TRANSDECODER_DIR.
#
# Использование:
#   ./run_transdecoder.sh file1.fa file2.fa ...
#   (без аргументов скрипт выведет эту справку)
# ============================================================

# ----------------------------
# Определение команд
# ----------------------------
if [[ -n "$TRANSDECODER_DIR" ]]; then
    LONGORFS="$TRANSDECODER_DIR/TransDecoder.LongOrfs"
    PREDICT="$TRANSDECODER_DIR/TransDecoder.Predict"
else
    LONGORFS="TransDecoder.LongOrfs"
    PREDICT="TransDecoder.Predict"
fi

# Проверка наличия команд
# Проверяем LongOrfs
if [[ "$LONGORFS" == /* ]]; then
    if [[ ! -x "$LONGORFS" ]]; then
        echo "Ошибка: Файл $LONGORFS не найден или не исполняемый." >&2
        exit 1
    fi
else
    if ! command -v "$LONGORFS" >/dev/null 2>&1; then
        echo "Ошибка: TransDecoder.LongOrfs не найден в PATH." >&2
        exit 1
    fi
fi

# Проверяем Predict
if [[ "$PREDICT" == /* ]]; then
    if [[ ! -x "$PREDICT" ]]; then
        echo "Ошибка: Файл $PREDICT не найден или не исполняемый." >&2
        exit 1
    fi
else
    if ! command -v "$PREDICT" >/dev/null 2>&1; then
        echo "Ошибка: TransDecoder.Predict не найден в PATH." >&2
        exit 1
    fi
fi

# ----------------------------
# Проверка аргументов
# ----------------------------
if [[ $# -eq 0 ]]; then
    echo "Использование: $0 file1.fa file2.fa ..."
    echo "Не передано ни одного FASTA-файла."
    exit 1
fi

# ----------------------------
# Функция обработки одного файла
# ----------------------------
run_transdecoder() {
    local fasta_file="$1"
    local base_name="${fasta_file%.fa}"

    echo "=============================================="
    echo "Обработка файла: $fasta_file"
    echo "Базовое имя: $base_name"
    echo "=============================================="

    if [[ ! -f "$fasta_file" ]]; then
        echo "ПРЕДУПРЕЖДЕНИЕ: файл $fasta_file не найден, пропускаю." >&2
        return 1
    fi

    echo "[1/2] Запуск TransDecoder.LongOrfs..."
    "$LONGORFS" -t "$fasta_file" || {
        echo "Ошибка при выполнении LongOrfs для $fasta_file" >&2
        return 1
    }

    echo "[2/2] Запуск TransDecoder.Predict..."
    "$PREDICT" -t "$fasta_file" --single_best_only || {
        echo "Ошибка при выполнении Predict для $fasta_file" >&2
        return 1
    }

    echo "Готово: $fasta_file"
    echo ""
}

# ----------------------------
# Главный цикл
# ----------------------------
for file in "$@"; do
    run_transdecoder "$file"
done

echo "Все файлы обработаны."
