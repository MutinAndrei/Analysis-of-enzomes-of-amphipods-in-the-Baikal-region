# ============================================================
# Основной скрипт пайплайна для анализа коррелирующих изоформ
# Описание: Автоматизирует весь процесс от DIAMOND-аннотации
#            до финальной таблицы с парами коррелирующих изоформ.
# ============================================================

# --- 1. Проверка и установка пакетов ---

# 1.1. Устанавливаем remotes
if (!requireNamespace("remotes", quietly = TRUE)) {
  install.packages("remotes")
}

# 1.2. Пакеты, которые точно есть в CRAN
cran_packages <- c(
  "dplyr", "tidyr", "tibble", "openxlsx",
  "httr", "jsonlite", "httr2", "checkmate"
)

# 1.3. Пакеты Bioconductor
bioc_packages <- c("Biostrings", "uniprotREST")

# 1.4. Устанавливаем BiocManager, если отсутствует
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager")
}

# 1.5. Устанавливаем недостающие CRAN-пакеты
missing_cran <- setdiff(cran_packages, rownames(installed.packages()))
if (length(missing_cran) > 0) {
  install.packages(missing_cran)
}

# 1.6. Устанавливаем недостающие Bioconductor-пакеты
missing_bioc <- setdiff(bioc_packages, rownames(installed.packages()))
if (length(missing_bioc) > 0) {
  BiocManager::install(missing_bioc)
}

# 1.7. Установка reutils
if (!requireNamespace("reutils", quietly = TRUE)) {
  remotes::install_version("reutils", version = "0.2.3",
                           repos = "https://cran.r-project.org")
}

# 1.8. Дополнительная страховка для uniprotREST
if (!requireNamespace("uniprotREST", quietly = TRUE)) {
  install.packages("uniprotREST", repos = "https://csdaw.r-universe.dev")
}

# 1.9. Подключаем все пакеты
all_packages <- c(cran_packages, bioc_packages, "reutils")
for (pkg in all_packages) {
  library(pkg, character.only = TRUE)
}

# --- 2. Автоматическое определение корневой директории ---

# Функция для получения пути к текущему скрипту
get_script_path <- function() {
  # Попытка получить путь при запуске через Rscript
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("--file=", args, value = TRUE)
  if (length(file_arg) > 0) {
    return(sub("--file=", "", file_arg))
  }
  
  # Попытка использовать rstudioapi
  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
    path <- rstudioapi::getActiveDocumentContext()$path
    if (nzchar(path)) return(path)
  }
  
  # Если ничего не найдено, возвращаем текущую рабочую директорию
  return(file.path(getwd(), "run_script.R"))
}

# Получаем полный путь к текущему скрипту
script_path <- get_script_path()
# Определяем каталог, в котором лежит run_script.R
base_dir <- dirname(normalizePath(script_path))
# Папка со скриптами
script_dir <- file.path(base_dir)
# Входные файлы
# diamond_file - это таблица результатов аннотации трнаскриптома с помощью софта dimond (https://bbuchfink.github.io/diamond/)
# Исходный DIAMOND-файл (та таблица что вы получили в ходе аннотации трнаскриптома)
raw_diamond_file <- file.path(base_dir, "Ever_cor.diamond.tsv")
# Подготовленный DIAMOND-файл (файл который будет создан и преобразован для анализа в данной программе)
diamond_file <- file.path(base_dir, "Ever_cor.diamond_new.tsv")
# matrix_file - это матрица значений экспрессии полученная пайплайна trinityrnaseq-v2.14.0 (https://github.com/trinityrnaseq/trinityrnaseq)
matrix_file <- file.path(base_dir, "MatrixEV.csv")
# Выходная директория
output_dir <- file.path(base_dir, "results") # Можно менять название выходной папки
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

# --- 3. Установка стороннего софта ---

# Пути к сторонему софту (MAFT и TransDecoder) 
# Если у вас нет этих программ вам необходимо их установить
# Чтобы установить MAFFT на линукс рекомендуется использовать bioconda (инструкция тут: https://anaconda.org/channels/bioconda/packages/mafft/overview)
# MAFFT для windows инструкция по установке https://mafft.cbrc.jp/alignment/software/windows.html
# Путь к MAFFT
mafft_path <- "/usr/bin/mafft"
# Чтобы установить TransDecoder на линукс рекомендуется использовать bioconda (инструкция тут: https://anaconda.org/channels/bioconda/packages/transdecoder/overview)
# Cпособ запустить TransDecoder на Windows — использовать WSL (Windows Subsystem for Linux) или пакетный менеджер Conda
# Пути к TransDecoder
transdecoder_dir <- "/media/Data/Work/miniconda3/bin" # Путь к TransDecoder
transdecoder_dir  <- normalizePath(path.expand(transdecoder_dir), mustWork = FALSE)
transdecoder_longorfs <- file.path(transdecoder_dir, "TransDecoder.LongOrfs")
transdecoder_predict  <- file.path(transdecoder_dir, "TransDecoder.Predict")
transdecoder_script   <- file.path(script_dir, "Transdecoder_scripst.sh")


# --- 2. Загрузка всех R-функций из папки ---
r_scripts <- c(
  "all_function_Zymap.R"
)

for (f in r_scripts) {
  full_path <- file.path(script_dir, f)
  if (file.exists(full_path)) {
    source(full_path)
    message("Загружен: ", f)
  } else {
    warning("Файл не найден: ", full_path)
  }
}

# --- 4. Параметры для шага 0 (аннотация EC) ---
# Индексы столбцов матрицы для переименования (пример для EV) (переименование необходимо для того чтобы объеденить повторности по предиктору и высчитать среднее)
# Если переименовывать не нужно игнорируйте
rename_indices <- c(18:21, 33:36)
rename_names <- c(
  "EveB12A_1", "EveB12A_2", "EveB12A_3", "EveB12A_4",
  "EveT1.5_1", "EveT1.5_2", "EveT1.5_3", "EveT1.5_4"
)
sample_pattern <- "^Eve[BT]"

# Выходной файл после аннотации (будет использован в шаге 1)
input_file_annotated <- file.path(output_dir, "30-01-2024_EConlynMATRIX4numbers_EV1.csv")

# Подготовка DIAMOND-файла
if (!file.exists(diamond_file)) {
  message("Подготовка DIAMOND-файла из исходного...")
  prepare_diamond_file(raw_diamond_file, diamond_file)
} else {
  message("Подготовленный DIAMOND-файл уже существует: ", diamond_file)
}

# --- 6. Шаг 0: Создание аннотированной матрицы экспрессии ---
message("--- Шаг 0: Аннотация EC из DIAMOND и UniProt ---")
if (!file.exists(input_file_annotated)) {
  process_diamond_and_expression(
    diamond_path   = diamond_file,
    matrix_path    = matrix_file,
    rename_indices = rename_indices,
    rename_names   = rename_names,
    sample_pattern = sample_pattern,
    output_file    = input_file_annotated
  )
} else {
  message("Аннотированный файл уже существует: ", input_file_annotated)
}

# --- 7. Параметры для последующих шагов ---
# Паттерн столбцов для широкой таблицы 
# Для другого предиктора нужно поменять часть ("EveT1.5", "EveB12", "EveB12A", "EveT12", "EveT18", "EveT24"). Остальные столбцы можно оставить так или настроить как вам удобно
pattern_EV <- c("gen", "EC.number", "EveT1.5", "EveB12", "EveB12A", "EveT12", "EveT18", "EveT24")

# Порядок колонок для финальной таблицы 
# Для другого предиктора нужно поменять чатсть ("EveT1.5", "EveB12", "EveB12A", "EveT12", "EveT18", "EveT24"). Остальные столбцы можно оставить так или настроить как вам удобно
final_pattern_EV <- c("EC.number", "gen", "description", "len", "PercentID", "maxmedian",
                      "EveT1.5", "EveB12", "EveB12A", "EveT12", "EveT18", "EveT24",
                      "seq_amino", "cor_temp", "mLen")

# Типы анализа
analysis_types <- c("E", "P") # Можно оставить что-то одно

# Параметры корреляции
cor_threshold <- -0.9 # Заменяемый коэффециент корреляции
cor_method <- "spearman" # или spearman
pairs_mode <- "strict"   # или "all_pairs", "best_pair" # подробное описание в теле функции 2_cor_fasta_function.R

# Температурный предиктор (соответствует порядку температур в pattern_EV)
temp_pred <- c(1.5, 6, 12, 12, 18, 24) # порядок вашего предиктора для корреляции

# Параметры для финальной фильтрации
run_temp_filter <- TRUE
temp_cor_threshold <- 0.4 # минимальный коэффециент корреляции с предиктором у обеих пар изоформ
temp_mLen_threshold <- 0.1 # минимальная разница длин первичной структруры у обеих пар изоформ

# Файл BRENDA
brenda_file <- file.path(base_dir, "brenda_2023_1.txt")
#фикс путей
fix_path <- function(p) {
  if (is.null(p) || !nzchar(p)) return(p)
  normalizePath(path.expand(p), mustWork = FALSE)
}

# --- 8. Основной цикл по типам анализа (E, P) ---
for (analis in analysis_types) {
  base_name <- paste0("EV_", ifelse(analis == "E", "exp", "per"))
  message("\n========== Обработка: ", base_name, " ==========\n")
  
  # Шаг 1: Процентная таблица
  percent_file <- file.path(output_dir, "percent_tableEV.csv")
  if (!file.exists(percent_file)) {
    calculate_percent_table(input_file = input_file_annotated, output_file = percent_file)
    message("[1] Процентная таблица сохранена: ", percent_file)
  } else {
    message("[1] Процентная таблица уже существует: ", percent_file)
  }
  
  # Шаг 2: FASTA с парами коррелирующих изоформ
  fasta_file <- file.path(output_dir, paste0(base_name, "_median.fa"))
  fastacreate_FUN(
    Data_table = percent_file,
    patern_column = pattern_EV,
    type_analisis = analis,
    name_fasta = fasta_file,
    cor_threshold = cor_threshold,
    cor_method = cor_method,
    mode = pairs_mode,
    save_pairs_csv = TRUE
  )
  message("[2] FASTA создан: ", fasta_file)
  
  # Шаг 3: TransDecoder (запуск через временную директорию БЕЗ пробелов)
  pep_file <- paste0(fasta_file, ".transdecoder.pep")
  if (file.exists(pep_file)) {
    message("[3] Готовый .pep файл найден: ", pep_file)
  } else {
    if (file.exists(transdecoder_script)) {
      
      message("[3] Папка проекта содержит пробелы. Запускаю безопасную обработку через /tmp/...")
      
      # 1. Создаем изолированную временную папку в системе (там точно нет пробелов)
      tmp_dir <- tempfile(pattern = "transdecoder_run_")
      dir.create(tmp_dir)
      
      # 2. Копируем исходный FASTA во временную папку
      fasta_basename <- basename(fasta_file)
      tmp_fasta <- file.path(tmp_dir, fasta_basename)
      file.copy(fasta_file, tmp_fasta)
      
      # 3. Запоминаем старую директорию и переходим во временную
      old_wd <- getwd()
      setwd(tmp_dir)
      
      # 4. Передаем путь к TransDecoder в окружение
      if (!is.null(transdecoder_dir) && nzchar(transdecoder_dir)) {
        Sys.setenv(TRANSDECODER_DIR = transdecoder_dir)
      }
      
      # 5. Запускаем bash-скрипт
      cmd <- paste("bash", shQuote(transdecoder_script), shQuote(fasta_basename))
      system(cmd)
      
      # 6. Проверяем, создался ли .pep файл во временной папке
      tmp_pep <- file.path(tmp_dir, paste0(fasta_basename, ".transdecoder.pep"))
      
      if (file.exists(tmp_pep)) {
        # Если всё успешно, копируем готовый .pep файл обратно в вашу папку результатов
        file.copy(tmp_pep, pep_file, overwrite = TRUE)
        message("[3] Результат успешно скопирован в: ", pep_file)
      }
      
      # 7. Возвращаемся назад и полностью удаляем временный мусор
      setwd(old_wd)
      unlink(tmp_dir, recursive = TRUE)
      
      message("[3] TransDecoder (bash) завершён.")
    } else {
      warning("[3] Bash-скрипт TransDecoder не найден, а готового .pep файла нет. Пропускаю обработку.")
      next
    }
    
    if (!file.exists(pep_file)) {
      stop("TransDecoder не создал .pep файл: ", pep_file,
           ". Проверьте запуск TransDecoder или укажите готовый файл.")
    }
  }
  
  # Шаг 4: Таблица пар с последовательностями
  corr_csv <- file.path(output_dir, paste0(base_name, "_cor.csv"))
  corr_table <- corrFUN(
    table_sp = percent_file,
    pattern_Sp = pattern_EV,
    trancdecoder_sp = pep_file,
    analis = analis,
    Pairs_or_not = "Pairs",
    cor_lvl = cor_threshold,
    cor_method = cor_method,
    brenda_file = brenda_file,
    save_csv = TRUE,
    output_file = corr_csv
  )
  message("[4] Таблица пар сохранена: ", corr_csv)
  
  # Шаг 5: Разделение FASTA по EC
  sepa_dir <- file.path(output_dir, paste0(base_name, "_EC_fastas"))
  sepaFastaby_EC(data_table = corr_csv, name_dir_to = sepa_dir)
  message("[5] FASTA по EC сохранены в: ", sepa_dir)
  
  # Шаг 6: Расчёт процента идентичности (MAFFT)
  wo100_csv <- file.path(output_dir, paste0(base_name, "_WO100.csv"))
  percent_id_table <- calc_percent_identity_mafft(
    aa_table = corr_table,
    mafft_path = mafft_path,
    threshold = 100,
    save_csv = TRUE,
    output_csv_file = wo100_csv
  )
  message("[6] Процент идентичности сохранён: ", wo100_csv)
  
  # Шаг 7: Финальная таблица с cor_temp и mLen
  final_xlsx <- file.path(output_dir, paste0("Final_table_", base_name, ".xlsx"))
  final_csv <- file.path(output_dir, paste0("Final_table_", base_name, ".csv"))
  final_table <- finDFcor(
    table_sp = percent_file,
    pattern_Sp = pattern_EV,
    patter_Sp_1 = final_pattern_EV,
    WO100 = wo100_csv,
    analis = analis,
    temp_predictor = temp_pred,
    temp_cor_method = cor_method, 
    save_xlsx = TRUE,
    save_name = file.path(output_dir, paste0("Final_table_", base_name)),
    save_csv = TRUE,
    output_csv_file = final_csv,
    brenda_file = brenda_file
  )
  message("[7] Финальная таблица создана: ", final_csv)
  
  # Шаг 8: Фильтрация по корреляции с температурой и разнице длин
  if (run_temp_filter) {
    filtered <- FunCorr_with_temp(
      df = final_xlsx,
      cor_temp = temp_cor_threshold,
      mLen = temp_mLen_threshold,
      save_output = TRUE,
      return_df = FALSE
    )
    message("[8] Фильтрация по температуре выполнена.")
    message("Пайплайн успешно завершён! Результаты в: ", output_dir)
  }
}
